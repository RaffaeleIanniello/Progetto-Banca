﻿namespace BancaMVC.Models
{
    public class PaginazioneViewModel
    {
        public List<Clienti> Clienti { get; set; }
        public List<Prestiti> Prestiti { get; set; }
        public int PaginaCorrente { get; set; }
        public int TotalePrestiti { get; set; }
        public int PrestitiPerPagina { get; set; }
        public int TotaleClienti { get; set; }
        public int ClientiPerPagina { get; set; }
        public string SearchString { get; set; }
        public string Ordinamento { get; set; }
    }
}
