﻿namespace BancaMVC.Models
{
    public class Banca
    {
        public int IDBanca {  get; set; }
        public string Denominazione { get; set; }
        public List<Clienti> ListaClienti { get; set; } = new List<Clienti>();
        public List<Prestiti> ListaPrestiti { get; set; } = new List<Prestiti>();

    }
}
