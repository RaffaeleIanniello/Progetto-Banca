﻿using System.ComponentModel.DataAnnotations;

namespace BancaMVC.Models
{
    public class Clienti
    {
        public int IDCliente { get; set; }

        [Display(Name = "NOME")]
        [Required(ErrorMessage = "Il campo Nome è obbligatorio.")]
        public string Nome { get; set; }
        
        [Display(Name = "COGNOME")]
        [Required(ErrorMessage = "Il campo Cognome è obbligatorio.")]
        public string Cognome { get; set; }
        
        
        [Display(Name = "CODICE FISCALE")]
        [StringLength(16, MinimumLength = 16, ErrorMessage = "Il Codice Fiscale deve essere di 16 caratteri.")]
        [RegularExpression(@"^[a-zA-Z]{6}\d{2}[a-zA-Z]\d{2}[a-zA-Z]\d{3}[a-zA-Z]$", ErrorMessage = "Sintassi del Codice Fiscale non valida")]
        [Required(ErrorMessage = "Il campo Codice Fiscale è obbligatorio.")]
        public string CodiceFiscale { get; set; }
        
        [Display(Name = "DATA DI NASCITA")]
        [Required(ErrorMessage = "Il campo Data Di Nascita è obbligatorio.")]
        public DateTime DataNascita { get; set; }
        [Display(Name = "STIPENDIO")]
        [Required(ErrorMessage = "Il campo Stipendio è obbligatorio.")]
        [Range(0, double.MaxValue, ErrorMessage = "Il campo Stipendio deve essere un valore positivo.")]
        public double Stipendio { get; set; }
        
    }
}
