﻿using System.ComponentModel.DataAnnotations;

namespace BancaMVC.Models
{
    public class Prestiti
    {
        public int IDPresito { get; set; }

        [Display(Name = "AMMONTARE")]
        [Required(ErrorMessage = "Il campo Ammontare è obbligatorio.")]
        public double Ammontare { get; set; } = 100;

        [Display(Name = "DATA INIZIO")]
        [Required(ErrorMessage = "Il campo Data Inizio è obbligatorio.")]
        public DateTime DataInizio { get; set; } = DateTime.Now;

        [Display(Name = "DATA FINE")]
        [Required(ErrorMessage = "Il campo Data Fine è obbligatorio.")]
        public DateTime DataFine { get; set; } = DateTime.Now;

        [Required(ErrorMessage = "Il campo Cliente è obbligatorio.")]
        public Clienti Cliente { get; set; }
        
        public double RataMensile()
        {

            if (DataFine < DataInizio)
            {
                return 0;
            }

            TimeSpan ts = new TimeSpan(DataFine.Ticks - DataInizio.Ticks);
            int Giorni = ts.Days;
            if (Giorni < 30)
                return 0;

            int NumeroRate = (DataFine.Year - DataInizio.Year) * 12 + (DataFine.Month - DataInizio.Month);
            NumeroRate++;
            double RataMensile = Ammontare / NumeroRate;
            return RataMensile;
        }
    }
}
