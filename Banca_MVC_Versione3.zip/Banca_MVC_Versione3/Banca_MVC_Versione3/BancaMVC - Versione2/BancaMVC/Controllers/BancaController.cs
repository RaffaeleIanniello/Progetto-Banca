﻿
using BancaMVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace BancaMVC.Controllers
{
    /// <summary>
    /// VERSIONE 3 DEL PROGETTO
    /// </summary>
    public class BancaController : Controller
    {
        /// <summary>
        /// INIZIALIZZAZIONE DELL'OGGETTO BANCA
        /// </summary>
        private static Banca banca = new Banca
        {
            IDBanca = 1,
            Denominazione = "Banca InQuery",
            ListaClienti = new List<Clienti>(),
            ListaPrestiti = new List<Prestiti>()
        };

        
        /// <summary>
        /// RITORNA OGGETTO CLIENTE
        /// </summary>
        /// <param name="clienteCF"></param>
        /// <returns></returns>
        public Clienti GetClienteByCf(string clienteCF)
        {
            var ClienteCF = banca.ListaClienti.Find(c => c.CodiceFiscale == clienteCF.ToUpper());
            return ClienteCF;
        }

        
        /// <summary>
        /// RITORNA LISTA PRESTITI
        /// </summary>
        /// <param name="prestitiCF"></param>
        /// <returns></returns>
        public List<Prestiti> GetPrestitiByCf(string prestitiCF)
        {
            List<Prestiti> PrestitiCF = banca.ListaPrestiti.Where(p => p.Cliente.CodiceFiscale == prestitiCF.ToUpper()).ToList();
            return PrestitiCF;
        }


        /// <summary>
        /// PAGINA PRINCIPALE
        /// </summary>
        /// <returns></returns>
        public IActionResult Index()
        {
            banca.ListaClienti = GeneraClienti(100);
            return View();
        }


        /// <summary>
        /// PAGINA DI ERRORE
        /// </summary>
        /// <returns></returns>
        public ActionResult ErrorPage()
        {
            return View();
        }


        /// <summary>
        /// CREAZIONE DI UN CLIENTE
        /// </summary>
        /// <param name="cliente"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult CreaCliente(Clienti cliente)
        {
            var clienteEs = GetClienteByCf(cliente.CodiceFiscale);
            if (clienteEs != null)
            {
                return RedirectToAction("ErrorPage");
            }
            {
                Clienti NuovoCliente = new Clienti();
                NuovoCliente.IDCliente = banca.ListaClienti.Count + 1;
                NuovoCliente.Nome = cliente.Nome.ToUpper();
                NuovoCliente.Cognome = cliente.Cognome.ToUpper();
                NuovoCliente.CodiceFiscale = cliente.CodiceFiscale.ToUpper();
                NuovoCliente.DataNascita = cliente.DataNascita;
                NuovoCliente.Stipendio = cliente.Stipendio;
                banca.ListaClienti.Add(NuovoCliente);
            }
            return RedirectToAction("MostraClienti");
        }
        [HttpGet]
        public ActionResult CreaCliente()
        {
            return View();
        }

        [HttpGet]
        public ActionResult MostraPrestiti(string ordinamento, int pagina = 1, int prestitiPerPagina = 5, string searchString = "")
        {
            var prestiti = banca.ListaPrestiti;
            if (!String.IsNullOrEmpty(searchString))
            {
                var Prestitis = banca.ListaPrestiti.Where(c => c.Cliente.Nome.Contains(searchString.ToUpper())
                || c.Cliente.Cognome.Contains(searchString.ToUpper())
                || c.Cliente.CodiceFiscale.Contains(searchString.ToUpper())).ToList();
                return View("DettaglioPrestiti", Prestitis);
            }
            switch (ordinamento)
            {
                case "nome":
                    prestiti = prestiti.OrderBy(c => c.Cliente.Nome).ToList();
                    break;
                case "cognome":
                    prestiti = prestiti.OrderBy(c => c.Cliente.Cognome).ToList();
                    break;
                case "codiceFiscale":
                    prestiti = prestiti.OrderBy(c => c.Cliente.CodiceFiscale).ToList();
                    break;
                case "ammontare":
                    prestiti = prestiti.OrderBy(c => c.Ammontare).ToList();
                    break;
                case "dataInizio":
                    prestiti = prestiti.OrderBy(c => c.DataInizio).ToList();
                    break;
                case "dataFine":
                    prestiti = prestiti.OrderBy(c => c.DataFine).ToList();
                    break;
                default:
                    prestiti = prestiti.OrderBy(c => c.Cliente.Nome).ToList();
                    break;
            }
            var prestitiPaginati = prestiti.Skip((pagina - 1) * prestitiPerPagina).Take(prestitiPerPagina).ToList();
            int totalePrestiti = prestiti.Count;
            var modelPrestiti = new PaginazioneViewModel
            {
                Prestiti = prestitiPaginati,
                PaginaCorrente = pagina,
                TotalePrestiti = totalePrestiti,
                PrestitiPerPagina = prestitiPerPagina,
                SearchString = searchString,
            };

            return View(modelPrestiti);
        }

        
        [HttpGet]
        public ActionResult MostraClienti(string ordinamento, int pagina = 1, int clientiPerPagina = 5, string searchString = "", bool dammiTutto = true)
        {
            var clienti = banca.ListaClienti;
            if (!String.IsNullOrEmpty(searchString))
            {
                var Clients = banca.ListaClienti.Where(c => c.Nome.Contains(searchString.ToUpper())
                || c.Cognome.Contains(searchString.ToUpper())
                || c.CodiceFiscale.Contains(searchString.ToUpper())).ToList();
                return View("DettaglioCliente", Clients);
            }
            switch (ordinamento)
            {
                case "nome":
                    clienti = clienti.OrderBy(c => c.Nome).ToList();
                    break;
                case "cognome":
                    clienti = clienti.OrderBy(c => c.Cognome).ToList();
                    break;
                case "codiceFiscale":
                    clienti = clienti.OrderBy(c => c.CodiceFiscale).ToList();
                    break;
                default:
                    clienti = clienti.OrderBy(c => c.Nome).ToList();
                    break;
            }
            var clientiPaginati = clienti.Skip((pagina - 1) * clientiPerPagina).Take(clientiPerPagina).ToList();
            int totaleClienti = clienti.Count;
            var model = new PaginazioneViewModel
            {
                Clienti = clientiPaginati,
                PaginaCorrente = pagina,
                TotaleClienti = totaleClienti,
                ClientiPerPagina = clientiPerPagina,
                SearchString = searchString,
                Ordinamento = ordinamento,
            };
            if (dammiTutto)
            {
                return View(model);
            }
            else
            {
                return PartialView("_MostraClientiPartial", model);
            }
            
        }
            
        
        
        /// <summary>
        /// ELIMINAZIONE DI UN CLIENTE ATTRAVERSO CODICE FISCALE
        /// </summary>
        /// <param name="codiceFiscale"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult EliminaCliente(string codiceFiscale)
        {
            var clienteEL = GetClienteByCf(codiceFiscale);
            if(clienteEL == null)
            {
                return RedirectToAction("ErrorPage");
            }
            else
            {
                return View(clienteEL);
            }
            
        }

        [HttpPost]
        public ActionResult EliminaCliente(Clienti cliente)
        {
            var clienteEl = GetClienteByCf(cliente.CodiceFiscale);
            if(clienteEl == null)
            {
                return RedirectToAction("ErrorPage");
            }
            else
            {
                banca.ListaClienti.Remove(clienteEl);
                List<Prestiti> EliminaPrestiti = GetPrestitiByCf(cliente.CodiceFiscale);
                foreach(var item in EliminaPrestiti)
                {
                    banca.ListaPrestiti.Remove(item);
                }
                return RedirectToAction("MostraClienti");
            }
        }
        


        /// <summary>
        /// MODIFICA DATI DI UN CLIENTE ATTRAVERSO CODICE FISCALE
        /// </summary>
        /// <param name="codiceFiscale"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult ModificaDatiCliente(string codiceFiscale)
        {
            var cliente = GetClienteByCf(codiceFiscale);
            if (cliente == null)
            {
                return RedirectToAction("ErrorPage");
            }
            return View(cliente);
        }

        [HttpPost]
        public ActionResult ModificaDatiCliente(Clienti cliente)
        {
            var clienteEx = GetClienteByCf(cliente.CodiceFiscale);
            if( clienteEx == null)
            {
                return RedirectToAction("ErrorPage");
            }
            else
            {
                clienteEx.Nome = cliente.Nome.ToUpper();
                clienteEx.Cognome = cliente.Cognome.ToUpper();
                clienteEx.Stipendio = cliente.Stipendio;
                clienteEx.IDCliente = banca.ListaClienti.Count + 1;
                clienteEx.DataNascita = cliente.DataNascita;
                return RedirectToAction("MostraClienti");
            }
        }

        
        /// <summary>
        /// AGGIUNTA DI UN PRESTITO AD UN CLIENTE ATTRAVERSO CODICE FISCALE
        /// </summary>
        /// <param name="prestiti"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult AggiungiPrestito(Prestiti prestiti)
        {
            var clientePrestito = GetClienteByCf(prestiti.Cliente.CodiceFiscale);
            if(clientePrestito == null)
            {
                return RedirectToAction("ErrorPage");
            }
            else
            {
                Prestiti NuovoPrestito = new Prestiti();
                NuovoPrestito.IDPresito = banca.ListaPrestiti.Count + 1;
                NuovoPrestito.DataInizio = prestiti.DataInizio;
                NuovoPrestito.DataFine = prestiti.DataFine;
                NuovoPrestito.Ammontare = prestiti.Ammontare;
                NuovoPrestito.Cliente = GetClienteByCf(prestiti.Cliente.CodiceFiscale);
                banca.ListaPrestiti.Add(NuovoPrestito);
                return RedirectToAction("MostraPrestiti");
            }
        }
        [HttpGet]
        public ActionResult AggiungiPrestito(string codiceFiscale)
        {
            var Cliente = GetClienteByCf(codiceFiscale);
            if (Cliente == null)
            {
                return RedirectToAction("ErrorPage");
            }
            else
            {
                Prestiti newPrestito = new Prestiti();
                newPrestito.Cliente = Cliente;
                return View(newPrestito);
            }

        }


        
        /// <summary>
        /// RICERCA PRESTITI AD UN CLIENTE ATTRAVERSO CODICE FISCALE
        /// </summary>
        /// <param name="prestiti"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult RicercaPrestitiCf(Prestiti prestiti)
        {
            List<Prestiti> PrestitiRicercati = GetPrestitiByCf(prestiti.Cliente.CodiceFiscale);
            if(PrestitiRicercati.Count == 0)
            {
                return RedirectToAction("ErrorPage");
            }
            else
            {
                return View("DettaglioPrestiti", PrestitiRicercati);
            }
        }
        [HttpGet]
        public ActionResult RicercaPrestitiCf()
        {
            return View();
        }


        /// <summary>
        /// CALCOLO DELL'AMMONTARE TOTALE DI UN CLIENTE ATTRAVERSO CODICE FISCALE
        /// </summary>
        /// <param name="codiceFiscale"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult AmmontareTotale(string codiceFiscale)
        {
            var prestiti = GetPrestitiByCf(codiceFiscale);
            if(prestiti.Count == 0)
            {
                return RedirectToAction("ErrorPage");
            }
            else
            {
                double TotaleAmmontare = prestiti.Sum(amm => amm.Ammontare);
                return View("TotaleAmmontamento", TotaleAmmontare);
            }
        }
        public static List<Clienti> GeneraClienti(int numeroDiClienti)
        {
            var random = new Random();
            var clientiList = new List<Clienti>();
            var nomi = new[] { "Mario", "Luigi", "Giovanni", "Luca", "Marco", "Alberto", "Ariosto", "Bruno", "Raffaele", "Simone", "Carlo" };
            var cognomi = new[] { "Rossi", "Bianchi", "Verdi", "Neri", "Gialli", "Senesi", "Del Piero", "Buffon", "Conti", "Napolitano", "Maresca" };

            for (int i = 0; i < numeroDiClienti; i++)
            {
                var cliente = new Clienti
                {
                    IDCliente = i + 1,
                    Nome = nomi[random.Next(nomi.Length)],
                    Cognome = cognomi[random.Next(cognomi.Length)],
                    CodiceFiscale = GeneraCodiceFiscale(random),
                    DataNascita = GeneraDataNascita(random),
                    Stipendio = random.NextDouble() * 100000
                };
                clientiList.Add(cliente);
            }

            return clientiList;
        }

        
        private static string GeneraCodiceFiscale(Random random)
        {
            const string lettere = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            const string numeri = "0123456789";

            var codice = new char[16];

            for (int i = 0; i < 6; i++)
                codice[i] = lettere[random.Next(lettere.Length)];

            for (int i = 6; i < 8; i++)
                codice[i] = numeri[random.Next(numeri.Length)];

            codice[8] = lettere[random.Next(lettere.Length)];

            for (int i = 9; i < 11; i++)
                codice[i] = numeri[random.Next(numeri.Length)];

            codice[11] = lettere[random.Next(lettere.Length)];

            for (int i = 12; i < 15; i++)
                codice[i] = numeri[random.Next(numeri.Length)];

            codice[15] = lettere[random.Next(lettere.Length)];

            return new string(codice);
        }

        private static DateTime GeneraDataNascita(Random random)
        {
            DateTime start = new DateTime(1950, 1, 1);
            int range = (DateTime.Today - start).Days;
            return start.AddDays(random.Next(range));
        }
    }
}
